// ============ PAGE NAVIGATION ============
function showPage(pageName) {
    // Hide all pages
    const pages = document.querySelectorAll('.page');
    pages.forEach(page => page.classList.remove('active'));
    
    // Show selected page
    const selectedPage = document.getElementById(pageName);
    if (selectedPage) {
        selectedPage.classList.add('active');
    }
    
    // Update navigation active state
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => link.classList.remove('active'));
    event.target.classList.add('active');
    
    // Load data for the page
    if (pageName === 'eda') {
        loadEDA();
    } else if (pageName === 'performance') {
        loadPerformance();
    } else if (pageName === 'predict') {
        loadSampleScenarios();
    }
}

// ============ API FUNCTIONS ============
const API_BASE = '/api';

async function apiCall(endpoint, method = 'GET', data = null) {
    try {
        const options = {
            method: method,
            headers: {
                'Content-Type': 'application/json'
            }
        };
        
        if (data) {
            options.body = JSON.stringify(data);
        }
        
        const response = await fetch(`${API_BASE}${endpoint}`, options);
        
        if (!response.ok) {
            throw new Error(`API Error: ${response.status}`);
        }
        
        return await response.json();
    } catch (error) {
        console.error('API Error:', error);
        showError(`Error: ${error.message}`);
        return null;
    }
}

// ============ PREDICTION FUNCTIONS ============
async function makePrediction() {
    const features = {
        crude_oil_price: parseFloat(document.getElementById('crudeOil').value),
        demand: parseFloat(document.getElementById('demand').value),
        supply: parseFloat(document.getElementById('supply').value),
        temperature: parseFloat(document.getElementById('temp').value),
        exchange_rate: parseFloat(document.getElementById('exchange').value),
        days_since_start: parseInt(document.getElementById('days').value)
    };
    
    const result = await apiCall('/predict', 'POST', features);
    
    if (result && result.success) {
        displayPredictionResult(result);
    }
}

function displayPredictionResult(result) {
    const resultDiv = document.getElementById('predictionResult');
    
    // Display main prediction
    document.getElementById('predictedPrice').textContent = 
        `₹${result.predicted_price}/L`;
    
    // Display confidence interval
    const ci = result.confidence_interval;
    document.getElementById('priceRange').textContent = 
        `₹${ci.lower} - ₹${ci.upper}`;
    
    // Display confidence score
    document.getElementById('confidence').textContent = 
        `${result.confidence_score}%`;
    
    // Display timestamp
    const date = new Date(result.timestamp);
    document.getElementById('timestamp').textContent = 
        date.toLocaleString();
    
    // Display input parameters
    const paramsGrid = document.getElementById('paramsGrid');
    paramsGrid.innerHTML = '';
    
    const params = result.input_features;
    const paramLabels = {
        'crude_oil_price': 'Crude Oil (USD/bbl)',
        'demand': 'Demand (units)',
        'supply': 'Supply (units)',
        'temperature': 'Temperature (°C)',
        'exchange_rate': 'Exchange Rate',
        'days_since_start': 'Days'
    };
    
    for (const [key, value] of Object.entries(params)) {
        const label = paramLabels[key] || key;
        const paramDiv = document.createElement('div');
        paramDiv.className = 'param-item';
        paramDiv.innerHTML = `
            <span class="param-label">${label}</span>
            <span class="param-value">${value.toFixed(2)}</span>
        `;
        paramsGrid.appendChild(paramDiv);
    }
    
    // Show result section
    resultDiv.style.display = 'block';
}

async function loadSampleScenarios() {
    const result = await apiCall('/sample-predictions');
    
    if (result && result.success) {
        const scenariosGrid = document.getElementById('scenariosGrid');
        scenariosGrid.innerHTML = '';
        
        result.predictions.forEach((pred, index) => {
            const card = document.createElement('div');
            card.className = 'scenario-card';
            card.innerHTML = `
                <div class="scenario-name">${pred.name}</div>
                <div class="scenario-price">₹${pred.price}/L</div>
                <button class="scenario-btn" onclick="applyScenario(${index})">
                    Use This Scenario
                </button>
            `;
            scenariosGrid.appendChild(card);
        });
        
        window.currentScenarios = result.predictions;
    }
}

function applyScenario(index) {
    const scenario = window.currentScenarios[index];
    const features = scenario.features;
    
    document.getElementById('crudeOil').value = features.crude_oil_price;
    document.getElementById('demand').value = features.demand;
    document.getElementById('supply').value = features.supply;
    document.getElementById('temp').value = features.temperature;
    document.getElementById('exchange').value = features.exchange_rate;
    document.getElementById('days').value = features.days_since_start;
    
    makePrediction();
}

// ============ EDA FUNCTIONS ============
async function loadEDA() {
    const result = await apiCall('/eda');
    
    if (result && result.success) {
        // Update stats
        document.getElementById('datasetSize').textContent = result.dataset_size;
        document.getElementById('featuresCount').textContent = result.features_count;
        document.getElementById('missingValues').textContent = result.missing_values;
        
        // Populate stats table
        const statsBody = document.getElementById('statsTableBody');
        statsBody.innerHTML = '';
        
        const stats = result.statistics;
        for (const [feature, data] of Object.entries(stats)) {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td><strong>${feature}</strong></td>
                <td>${data.mean.toFixed(2)}</td>
                <td>${data.std.toFixed(2)}</td>
                <td>${data.min.toFixed(2)}</td>
                <td>${data.max.toFixed(2)}</td>
            `;
            statsBody.appendChild(row);
        }
        
        // Populate sample data table
        const sampleBody = document.getElementById('sampleTableBody');
        sampleBody.innerHTML = '';
        
        result.sample_data.forEach(row => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${row.crude_oil_price.toFixed(2)}</td>
                <td>${row.demand.toFixed(2)}</td>
                <td>${row.supply.toFixed(2)}</td>
                <td>${row.temperature.toFixed(2)}</td>
                <td>${row.exchange_rate.toFixed(2)}</td>
                <td>${row.days_since_start}</td>
                <td><strong>${row.petrol_price.toFixed(2)}</strong></td>
            `;
            sampleBody.appendChild(tr);
        });
    }
}

// ============ PERFORMANCE FUNCTIONS ============
async function loadPerformance() {
    const result = await apiCall('/model-performance');
    
    if (result && result.success) {
        const models = result.models;
        
        // Populate performance table
        const perfBody = document.getElementById('performanceTableBody');
        perfBody.innerHTML = '';
        
        models.forEach(model => {
            const row = document.createElement('tr');
            const statusBadge = model.status === 'best' ? 
                '<span style="background: #2ca02c; color: white; padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.85rem;">✓ Best</span>' : 
                '<span style="background: #999; color: white; padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.85rem;">Active</span>';
            
            row.innerHTML = `
                <td><strong>${model.name}</strong></td>
                <td>${model.r2_score.toFixed(4)}</td>
                <td>${model.rmse.toFixed(4)}</td>
                <td>${model.mae.toFixed(4)}</td>
                <td>${model.cv_score.toFixed(4)}</td>
                <td>${statusBadge}</td>
            `;
            perfBody.appendChild(row);
        });
        
        // Create charts
        createPerformanceCharts(models);
    }
}

function createPerformanceCharts(models) {
    // R² Score Chart
    const r2Ctx = document.getElementById('r2Chart');
    if (r2Ctx && r2Ctx.chart) {
        r2Ctx.chart.destroy();
    }
    
    new Chart(r2Ctx, {
        type: 'bar',
        data: {
            labels: models.map(m => m.name),
            datasets: [{
                label: 'R² Score',
                data: models.map(m => m.r2_score),
                backgroundColor: models.map(m => m.status === 'best' ? '#2ca02c' : '#1f77b4'),
                borderRadius: 8,
                borderSkipped: false
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 1
                }
            }
        }
    });
    r2Ctx.chart = true;
    
    // RMSE Chart
    const rmseCtx = document.getElementById('rmseChart');
    if (rmseCtx && rmseCtx.chart) {
        rmseCtx.chart.destroy();
    }
    
    new Chart(rmseCtx, {
        type: 'bar',
        data: {
            labels: models.map(m => m.name),
            datasets: [{
                label: 'RMSE',
                data: models.map(m => m.rmse),
                backgroundColor: models.map(m => m.status === 'best' ? '#2ca02c' : '#ff7f0e'),
                borderRadius: 8,
                borderSkipped: false
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
    rmseCtx.chart = true;
}

// ============ UTILITY FUNCTIONS ============
function showError(message) {
    alert(`❌ ${message}`);
}

// ============ INITIALIZATION ============
document.addEventListener('DOMContentLoaded', () => {
    // Load initial data
    loadSampleScenarios();
    
    // Set default active nav link
    document.querySelector('.nav-link').classList.add('active');
    
    console.log('⛽ Petrol Price Predictor loaded successfully');
});
