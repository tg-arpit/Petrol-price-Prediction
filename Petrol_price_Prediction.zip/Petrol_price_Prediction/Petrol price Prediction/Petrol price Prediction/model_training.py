"""
Petrol Price Prediction Model
Machine Learning Pipeline using Scikit-learn, Pandas, NumPy
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression, Ridge, Lasso
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
import pickle
import warnings
warnings.filterwarnings('ignore')

class PetrolPricePredictor:
    """
    Machine learning model for predicting petrol prices
    """
    
    def __init__(self):
        self.model = None
        self.scaler = StandardScaler()
        self.X_train = None
        self.X_test = None
        self.y_train = None
        self.y_test = None
        self.metrics = {}
        
    def generate_sample_data(self, n_samples=500):
        """Generate realistic synthetic petrol price data"""
        np.random.seed(42)
        
        crude_oil_price = np.random.uniform(40, 120, n_samples)
        demand = np.random.uniform(1000, 2000, n_samples)
        supply = np.random.uniform(900, 2100, n_samples)
        temperature = np.random.uniform(10, 45, n_samples)
        exchange_rate = np.random.uniform(70, 85, n_samples)
        petrol_price = (
            crude_oil_price * 0.8 +
            demand * 0.001 +
            (2000 - supply) * 0.0005 +
            temperature * 0.1 +
            exchange_rate * 0.5 +
            np.random.normal(0, 5, n_samples)
        )
        
        df = pd.DataFrame({
            'crude_oil_price': crude_oil_price,
            'demand': demand,
            'supply': supply,
            'temperature': temperature,
            'exchange_rate': exchange_rate,
            'petrol_price': petrol_price
        })
        
        return df
    
    def preprocess_data(self, df):
        """Preprocess data"""
        X = df.drop('petrol_price', axis=1)
        y = df['petrol_price']
        
        self.X_train, self.X_test, self.y_train, self.y_test = train_test_split(
            X, y, test_size=0.2, random_state=42
        )
        
        self.X_train_scaled = self.scaler.fit_transform(self.X_train)
        self.X_test_scaled = self.scaler.transform(self.X_test)
        
        return self.X_train_scaled, self.X_test_scaled
    
    def train_multiple_models(self):
        """Train multiple regression models"""
        models = {
            'Linear Regression': LinearRegression(),
            'Ridge Regression': Ridge(alpha=1.0),
            'Lasso Regression': Lasso(alpha=0.1),
            'Random Forest': RandomForestRegressor(n_estimators=100, random_state=42),
            'Gradient Boosting': GradientBoostingRegressor(n_estimators=100, random_state=42)
        }
        
        results = {}
        
        for name, model in models.items():
            model.fit(self.X_train_scaled, self.y_train)
            
            y_pred_train = model.predict(self.X_train_scaled)
            y_pred_test = model.predict(self.X_test_scaled)
            
            train_r2 = r2_score(self.y_train, y_pred_train)
            test_r2 = r2_score(self.y_test, y_pred_test)
            train_rmse = np.sqrt(mean_squared_error(self.y_train, y_pred_train))
            test_rmse = np.sqrt(mean_squared_error(self.y_test, y_pred_test))
            test_mae = mean_absolute_error(self.y_test, y_pred_test)
            
            cv_scores = cross_val_score(model, self.X_train_scaled, self.y_train, 
                                       cv=5, scoring='r2')
            
            results[name] = {
                'model': model,
                'train_r2': train_r2,
                'test_r2': test_r2,
                'train_rmse': train_rmse,
                'test_rmse': test_rmse,
                'mae': test_mae,
                'cv_mean': cv_scores.mean(),
                'cv_std': cv_scores.std(),
                'predictions': y_pred_test
            }
        
        return results
    
    def select_best_model(self, results):
        """Select best performing model"""
        best_model_name = max(results, key=lambda x: results[x]['test_r2'])
        self.model = results[best_model_name]['model']
        self.metrics = results[best_model_name]
        
        return best_model_name
    
    def save_model(self, model_name='petrol_price_model'):
        """Save trained model"""
        import os
        os.makedirs('models', exist_ok=True)
        
        with open(f'models/{model_name}.pkl', 'wb') as f:
            pickle.dump(self.model, f)
        
        with open(f'models/scaler.pkl', 'wb') as f:
            pickle.dump(self.scaler, f)
    
    def load_model(self, model_name='petrol_price_model'):
        """Load trained model"""
        with open(f'models/{model_name}.pkl', 'rb') as f:
            self.model = pickle.load(f)
        
        with open(f'models/scaler.pkl', 'rb') as f:
            self.scaler = pickle.load(f)
    
    def predict(self, features_dict):
        """Make a prediction"""
        features_df = pd.DataFrame([features_dict])
        features_scaled = self.scaler.transform(features_df)
        prediction = self.model.predict(features_scaled)[0]
        return prediction
    
    def run_complete_pipeline(self):
        """Execute complete ML pipeline"""
        print("\n" + "="*60)
        print("PETROL PRICE PREDICTION - TRAINING PIPELINE")
        print("="*60)
        
        df = self.generate_sample_data(n_samples=500)
        print(f"✓ Dataset generated: {df.shape[0]} samples, {df.shape[1]} features")
        
        self.preprocess_data(df)
        print("✓ Data preprocessed and scaled")
        
        results = self.train_multiple_models()
        print("✓ All models trained")
        
        best_model_name = self.select_best_model(results)
        print(f"✓ Best model selected: {best_model_name}")
        
        self.save_model()
        print("✓ Model saved to disk")
        
        print("\n" + "="*60)
        print("TRAINING COMPLETED")
        print("="*60 + "\n")
        
        return self.model, self.metrics
